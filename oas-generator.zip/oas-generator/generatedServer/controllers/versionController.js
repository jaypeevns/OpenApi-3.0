'use strict'

var varversionController = require('./versionControllerService');

module.exports.SystemVersion = function SystemVersion(req, res, next) {
  varversionController.SystemVersion(req.swagger.params, res, next);
};