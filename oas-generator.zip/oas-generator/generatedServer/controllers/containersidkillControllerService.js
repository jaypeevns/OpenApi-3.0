'use strict'

module.exports.ContainerKill = function ContainerKill(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ContainerKill'
  });
};