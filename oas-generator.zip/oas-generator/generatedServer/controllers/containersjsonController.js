'use strict'

var varcontainersjsonController = require('./containersjsonControllerService');

module.exports.ContainerList = function ContainerList(req, res, next) {
  varcontainersjsonController.ContainerList(req.swagger.params, res, next);
};