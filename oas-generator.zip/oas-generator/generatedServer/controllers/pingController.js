'use strict'

var varpingController = require('./pingControllerService');

module.exports.SystemPing = function SystemPing(req, res, next) {
  varpingController.SystemPing(req.swagger.params, res, next);
};