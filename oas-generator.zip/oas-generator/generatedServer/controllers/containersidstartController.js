'use strict'

var varcontainersidstartController = require('./containersidstartControllerService');

module.exports.ContainerStart = function ContainerStart(req, res, next) {
  varcontainersidstartController.ContainerStart(req.swagger.params, res, next);
};