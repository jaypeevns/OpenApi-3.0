'use strict'

var varsessionController = require('./sessionControllerService');

module.exports.Session = function Session(req, res, next) {
  varsessionController.Session(req.swagger.params, res, next);
};