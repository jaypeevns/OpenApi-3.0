'use strict'

module.exports.SystemPing = function SystemPing(req, res, next) {
  res.send({
    message: 'This is the mockup controller for SystemPing'
  });
};