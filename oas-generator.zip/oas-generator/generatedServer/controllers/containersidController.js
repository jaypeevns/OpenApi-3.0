'use strict'

var varcontainersidController = require('./containersidControllerService');

module.exports.ContainerDelete = function ContainerDelete(req, res, next) {
  varcontainersidController.ContainerDelete(req.swagger.params, res, next);
};