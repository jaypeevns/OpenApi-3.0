'use strict'

module.exports.SecretUpdate = function SecretUpdate(req, res, next) {
  res.send({
    message: 'This is the mockup controller for SecretUpdate'
  });
};