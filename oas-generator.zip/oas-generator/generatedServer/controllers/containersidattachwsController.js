'use strict'

var varcontainersidattachwsController = require('./containersidattachwsControllerService');

module.exports.ContainerAttachWebsocket = function ContainerAttachWebsocket(req, res, next) {
  varcontainersidattachwsController.ContainerAttachWebsocket(req.swagger.params, res, next);
};