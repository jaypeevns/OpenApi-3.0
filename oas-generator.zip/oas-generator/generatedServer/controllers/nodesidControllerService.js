'use strict'

module.exports.NodeDelete = function NodeDelete(req, res, next) {
  res.send({
    message: 'This is the mockup controller for NodeDelete'
  });
};

module.exports.NodeInspect = function NodeInspect(req, res, next) {
  res.send({
    message: 'This is the mockup controller for NodeInspect'
  });
};