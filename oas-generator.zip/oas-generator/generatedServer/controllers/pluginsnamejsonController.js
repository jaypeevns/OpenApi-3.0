'use strict'

var varpluginsnamejsonController = require('./pluginsnamejsonControllerService');

module.exports.PluginInspect = function PluginInspect(req, res, next) {
  varpluginsnamejsonController.PluginInspect(req.swagger.params, res, next);
};