'use strict'

module.exports.ContainerDelete = function ContainerDelete(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ContainerDelete'
  });
};