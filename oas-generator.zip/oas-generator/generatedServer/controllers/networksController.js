'use strict'

var varnetworksController = require('./networksControllerService');

module.exports.NetworkList = function NetworkList(req, res, next) {
  varnetworksController.NetworkList(req.swagger.params, res, next);
};