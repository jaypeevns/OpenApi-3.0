'use strict'

var varpluginscreateController = require('./pluginscreateControllerService');

module.exports.PluginCreate = function PluginCreate(req, res, next) {
  varpluginscreateController.PluginCreate(req.swagger.params, res, next);
};