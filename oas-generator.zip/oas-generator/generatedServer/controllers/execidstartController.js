'use strict'

var varexecidstartController = require('./execidstartControllerService');

module.exports.ExecStart = function ExecStart(req, res, next) {
  varexecidstartController.ExecStart(req.swagger.params, res, next);
};