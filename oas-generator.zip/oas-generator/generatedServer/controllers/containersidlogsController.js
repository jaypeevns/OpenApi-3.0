'use strict'

var varcontainersidlogsController = require('./containersidlogsControllerService');

module.exports.ContainerLogs = function ContainerLogs(req, res, next) {
  varcontainersidlogsController.ContainerLogs(req.swagger.params, res, next);
};