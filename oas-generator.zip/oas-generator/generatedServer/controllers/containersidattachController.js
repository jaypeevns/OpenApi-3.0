'use strict'

var varcontainersidattachController = require('./containersidattachControllerService');

module.exports.ContainerAttach = function ContainerAttach(req, res, next) {
  varcontainersidattachController.ContainerAttach(req.swagger.params, res, next);
};