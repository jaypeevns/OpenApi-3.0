'use strict'

var varinfoController = require('./infoControllerService');

module.exports.SystemInfo = function SystemInfo(req, res, next) {
  varinfoController.SystemInfo(req.swagger.params, res, next);
};