'use strict'

module.exports.VolumePrune = function VolumePrune(req, res, next) {
  res.send({
    message: 'This is the mockup controller for VolumePrune'
  });
};