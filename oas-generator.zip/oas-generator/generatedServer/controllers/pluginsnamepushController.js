'use strict'

var varpluginsnamepushController = require('./pluginsnamepushControllerService');

module.exports.PluginPush = function PluginPush(req, res, next) {
  varpluginsnamepushController.PluginPush(req.swagger.params, res, next);
};