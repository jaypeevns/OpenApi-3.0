'use strict'

module.exports.SecretDelete = function SecretDelete(req, res, next) {
  res.send({
    message: 'This is the mockup controller for SecretDelete'
  });
};

module.exports.SecretInspect = function SecretInspect(req, res, next) {
  res.send({
    message: 'This is the mockup controller for SecretInspect'
  });
};