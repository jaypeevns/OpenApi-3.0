'use strict'

module.exports.ImageInspect = function ImageInspect(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ImageInspect'
  });
};