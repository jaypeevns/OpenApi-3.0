'use strict'

var varsecretsController = require('./secretsControllerService');

module.exports.SecretList = function SecretList(req, res, next) {
  varsecretsController.SecretList(req.swagger.params, res, next);
};