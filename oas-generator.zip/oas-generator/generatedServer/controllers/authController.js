'use strict'

var varauthController = require('./authControllerService');

module.exports.SystemAuth = function SystemAuth(req, res, next) {
  varauthController.SystemAuth(req.swagger.params, res, next);
};