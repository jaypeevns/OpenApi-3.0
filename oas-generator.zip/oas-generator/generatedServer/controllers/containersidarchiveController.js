'use strict'

var varcontainersidarchiveController = require('./containersidarchiveControllerService');

module.exports.ContainerArchive = function ContainerArchive(req, res, next) {
  varcontainersidarchiveController.ContainerArchive(req.swagger.params, res, next);
};

module.exports.ContainerArchiveInfo = function ContainerArchiveInfo(req, res, next) {
  varcontainersidarchiveController.ContainerArchiveInfo(req.swagger.params, res, next);
};

module.exports.PutContainerArchive = function PutContainerArchive(req, res, next) {
  varcontainersidarchiveController.PutContainerArchive(req.swagger.params, res, next);
};