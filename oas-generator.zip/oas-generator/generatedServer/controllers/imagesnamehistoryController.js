'use strict'

var varimagesnamehistoryController = require('./imagesnamehistoryControllerService');

module.exports.ImageHistory = function ImageHistory(req, res, next) {
  varimagesnamehistoryController.ImageHistory(req.swagger.params, res, next);
};