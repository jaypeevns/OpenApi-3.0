'use strict'

var varswarmleaveController = require('./swarmleaveControllerService');

module.exports.SwarmLeave = function SwarmLeave(req, res, next) {
  varswarmleaveController.SwarmLeave(req.swagger.params, res, next);
};