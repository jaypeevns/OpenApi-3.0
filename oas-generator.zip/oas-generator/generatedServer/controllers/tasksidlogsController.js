'use strict'

var vartasksidlogsController = require('./tasksidlogsControllerService');

module.exports.TaskLogs = function TaskLogs(req, res, next) {
  vartasksidlogsController.TaskLogs(req.swagger.params, res, next);
};