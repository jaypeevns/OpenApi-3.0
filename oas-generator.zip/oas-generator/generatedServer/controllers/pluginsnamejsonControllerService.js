'use strict'

module.exports.PluginInspect = function PluginInspect(req, res, next) {
  res.send({
    message: 'This is the mockup controller for PluginInspect'
  });
};