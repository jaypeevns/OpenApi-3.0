'use strict'

module.exports.ImageGetAll = function ImageGetAll(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ImageGetAll'
  });
};