'use strict'

var varimagesnamegetController = require('./imagesnamegetControllerService');

module.exports.ImageGet = function ImageGet(req, res, next) {
  varimagesnamegetController.ImageGet(req.swagger.params, res, next);
};