'use strict'

module.exports.VolumeCreate = function VolumeCreate(req, res, next) {
  res.send({
    message: 'This is the mockup controller for VolumeCreate'
  });
};