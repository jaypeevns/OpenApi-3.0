'use strict'

var varconfigsidController = require('./configsidControllerService');

module.exports.ConfigDelete = function ConfigDelete(req, res, next) {
  varconfigsidController.ConfigDelete(req.swagger.params, res, next);
};

module.exports.ConfigInspect = function ConfigInspect(req, res, next) {
  varconfigsidController.ConfigInspect(req.swagger.params, res, next);
};