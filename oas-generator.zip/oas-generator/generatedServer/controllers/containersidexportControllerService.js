'use strict'

module.exports.ContainerExport = function ContainerExport(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ContainerExport'
  });
};