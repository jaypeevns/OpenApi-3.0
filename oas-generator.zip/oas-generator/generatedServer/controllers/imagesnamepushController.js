'use strict'

var varimagesnamepushController = require('./imagesnamepushControllerService');

module.exports.ImagePush = function ImagePush(req, res, next) {
  varimagesnamepushController.ImagePush(req.swagger.params, res, next);
};