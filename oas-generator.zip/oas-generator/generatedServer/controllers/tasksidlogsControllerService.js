'use strict'

module.exports.TaskLogs = function TaskLogs(req, res, next) {
  res.send({
    message: 'This is the mockup controller for TaskLogs'
  });
};