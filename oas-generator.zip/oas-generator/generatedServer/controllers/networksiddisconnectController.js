'use strict'

var varnetworksiddisconnectController = require('./networksiddisconnectControllerService');

module.exports.NetworkDisconnect = function NetworkDisconnect(req, res, next) {
  varnetworksiddisconnectController.NetworkDisconnect(req.swagger.params, res, next);
};