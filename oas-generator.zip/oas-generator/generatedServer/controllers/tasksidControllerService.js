'use strict'

module.exports.TaskInspect = function TaskInspect(req, res, next) {
  res.send({
    message: 'This is the mockup controller for TaskInspect'
  });
};