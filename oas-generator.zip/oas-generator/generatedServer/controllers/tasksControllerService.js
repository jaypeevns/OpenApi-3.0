'use strict'

module.exports.TaskList = function TaskList(req, res, next) {
  res.send({
    message: 'This is the mockup controller for TaskList'
  });
};