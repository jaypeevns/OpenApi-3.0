'use strict'

module.exports.PluginUpgrade = function PluginUpgrade(req, res, next) {
  res.send({
    message: 'This is the mockup controller for PluginUpgrade'
  });
};