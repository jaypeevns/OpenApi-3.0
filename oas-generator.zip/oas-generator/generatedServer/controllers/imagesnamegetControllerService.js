'use strict'

module.exports.ImageGet = function ImageGet(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ImageGet'
  });
};