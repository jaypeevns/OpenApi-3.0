'use strict'

module.exports.ImageDelete = function ImageDelete(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ImageDelete'
  });
};