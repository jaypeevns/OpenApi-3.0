'use strict'

var vareventsController = require('./eventsControllerService');

module.exports.SystemEvents = function SystemEvents(req, res, next) {
  vareventsController.SystemEvents(req.swagger.params, res, next);
};