'use strict'

var varcontainerscreateController = require('./containerscreateControllerService');

module.exports.ContainerCreate = function ContainerCreate(req, res, next) {
  varcontainerscreateController.ContainerCreate(req.swagger.params, res, next);
};