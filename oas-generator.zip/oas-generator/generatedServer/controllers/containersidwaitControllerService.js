'use strict'

module.exports.ContainerWait = function ContainerWait(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ContainerWait'
  });
};