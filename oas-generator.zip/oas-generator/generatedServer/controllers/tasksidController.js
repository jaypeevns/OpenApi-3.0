'use strict'

var vartasksidController = require('./tasksidControllerService');

module.exports.TaskInspect = function TaskInspect(req, res, next) {
  vartasksidController.TaskInspect(req.swagger.params, res, next);
};