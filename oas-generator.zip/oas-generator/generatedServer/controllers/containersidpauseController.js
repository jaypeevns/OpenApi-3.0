'use strict'

var varcontainersidpauseController = require('./containersidpauseControllerService');

module.exports.ContainerPause = function ContainerPause(req, res, next) {
  varcontainersidpauseController.ContainerPause(req.swagger.params, res, next);
};