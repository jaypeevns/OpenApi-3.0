'use strict'

var varservicesidlogsController = require('./servicesidlogsControllerService');

module.exports.ServiceLogs = function ServiceLogs(req, res, next) {
  varservicesidlogsController.ServiceLogs(req.swagger.params, res, next);
};