'use strict'

var varpluginsnameController = require('./pluginsnameControllerService');

module.exports.PluginDelete = function PluginDelete(req, res, next) {
  varpluginsnameController.PluginDelete(req.swagger.params, res, next);
};