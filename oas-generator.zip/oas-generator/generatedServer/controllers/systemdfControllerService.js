'use strict'

module.exports.SystemDataUsage = function SystemDataUsage(req, res, next) {
  res.send({
    message: 'This is the mockup controller for SystemDataUsage'
  });
};