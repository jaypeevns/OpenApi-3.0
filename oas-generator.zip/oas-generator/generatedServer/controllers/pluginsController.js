'use strict'

var varpluginsController = require('./pluginsControllerService');

module.exports.PluginList = function PluginList(req, res, next) {
  varpluginsController.PluginList(req.swagger.params, res, next);
};