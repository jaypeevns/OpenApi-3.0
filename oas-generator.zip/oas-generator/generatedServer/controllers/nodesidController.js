'use strict'

var varnodesidController = require('./nodesidControllerService');

module.exports.NodeDelete = function NodeDelete(req, res, next) {
  varnodesidController.NodeDelete(req.swagger.params, res, next);
};

module.exports.NodeInspect = function NodeInspect(req, res, next) {
  varnodesidController.NodeInspect(req.swagger.params, res, next);
};