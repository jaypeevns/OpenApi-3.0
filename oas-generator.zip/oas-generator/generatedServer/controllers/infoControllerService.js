'use strict'

module.exports.SystemInfo = function SystemInfo(req, res, next) {
  res.send({
    message: 'This is the mockup controller for SystemInfo'
  });
};