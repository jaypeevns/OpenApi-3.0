'use strict'

module.exports.ImagePush = function ImagePush(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ImagePush'
  });
};