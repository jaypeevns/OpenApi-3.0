'use strict'

var varcontainersidunpauseController = require('./containersidunpauseControllerService');

module.exports.ContainerUnpause = function ContainerUnpause(req, res, next) {
  varcontainersidunpauseController.ContainerUnpause(req.swagger.params, res, next);
};