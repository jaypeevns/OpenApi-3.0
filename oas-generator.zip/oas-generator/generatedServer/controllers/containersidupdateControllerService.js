'use strict'

module.exports.ContainerUpdate = function ContainerUpdate(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ContainerUpdate'
  });
};