'use strict'

module.exports.ContainerAttach = function ContainerAttach(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ContainerAttach'
  });
};