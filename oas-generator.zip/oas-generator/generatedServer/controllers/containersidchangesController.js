'use strict'

var varcontainersidchangesController = require('./containersidchangesControllerService');

module.exports.ContainerChanges = function ContainerChanges(req, res, next) {
  varcontainersidchangesController.ContainerChanges(req.swagger.params, res, next);
};