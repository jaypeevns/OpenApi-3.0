'use strict'

var varswarmjoinController = require('./swarmjoinControllerService');

module.exports.SwarmJoin = function SwarmJoin(req, res, next) {
  varswarmjoinController.SwarmJoin(req.swagger.params, res, next);
};