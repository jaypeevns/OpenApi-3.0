'use strict'

var varnodesController = require('./nodesControllerService');

module.exports.NodeList = function NodeList(req, res, next) {
  varnodesController.NodeList(req.swagger.params, res, next);
};