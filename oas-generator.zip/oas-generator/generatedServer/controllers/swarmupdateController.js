'use strict'

var varswarmupdateController = require('./swarmupdateControllerService');

module.exports.SwarmUpdate = function SwarmUpdate(req, res, next) {
  varswarmupdateController.SwarmUpdate(req.swagger.params, res, next);
};