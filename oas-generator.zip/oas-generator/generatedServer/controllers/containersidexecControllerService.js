'use strict'

module.exports.ContainerExec = function ContainerExec(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ContainerExec'
  });
};