'use strict'

var varcontainersidexportController = require('./containersidexportControllerService');

module.exports.ContainerExport = function ContainerExport(req, res, next) {
  varcontainersidexportController.ContainerExport(req.swagger.params, res, next);
};