'use strict'

module.exports.ServiceList = function ServiceList(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ServiceList'
  });
};