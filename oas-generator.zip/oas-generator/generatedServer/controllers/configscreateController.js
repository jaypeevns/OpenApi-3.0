'use strict'

var varconfigscreateController = require('./configscreateControllerService');

module.exports.ConfigCreate = function ConfigCreate(req, res, next) {
  varconfigscreateController.ConfigCreate(req.swagger.params, res, next);
};