'use strict'

var vardistributionnamejsonController = require('./distributionnamejsonControllerService');

module.exports.DistributionInspect = function DistributionInspect(req, res, next) {
  vardistributionnamejsonController.DistributionInspect(req.swagger.params, res, next);
};