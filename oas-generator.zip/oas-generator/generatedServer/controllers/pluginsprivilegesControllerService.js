'use strict'

module.exports.GetPluginPrivileges = function GetPluginPrivileges(req, res, next) {
  res.send({
    message: 'This is the mockup controller for GetPluginPrivileges'
  });
};