'use strict'

var varcontainersidtopController = require('./containersidtopControllerService');

module.exports.ContainerTop = function ContainerTop(req, res, next) {
  varcontainersidtopController.ContainerTop(req.swagger.params, res, next);
};