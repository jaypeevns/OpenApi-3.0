'use strict'

var varswarmunlockController = require('./swarmunlockControllerService');

module.exports.SwarmUnlock = function SwarmUnlock(req, res, next) {
  varswarmunlockController.SwarmUnlock(req.swagger.params, res, next);
};