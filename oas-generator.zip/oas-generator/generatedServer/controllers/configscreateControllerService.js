'use strict'

module.exports.ConfigCreate = function ConfigCreate(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ConfigCreate'
  });
};