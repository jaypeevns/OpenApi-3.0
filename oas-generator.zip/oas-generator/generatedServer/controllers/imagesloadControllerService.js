'use strict'

module.exports.ImageLoad = function ImageLoad(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ImageLoad'
  });
};