'use strict'

var varcontainersidexecController = require('./containersidexecControllerService');

module.exports.ContainerExec = function ContainerExec(req, res, next) {
  varcontainersidexecController.ContainerExec(req.swagger.params, res, next);
};