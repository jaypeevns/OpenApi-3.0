'use strict'

var varnetworkspruneController = require('./networkspruneControllerService');

module.exports.NetworkPrune = function NetworkPrune(req, res, next) {
  varnetworkspruneController.NetworkPrune(req.swagger.params, res, next);
};