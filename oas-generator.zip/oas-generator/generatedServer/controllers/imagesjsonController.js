'use strict'

var varimagesjsonController = require('./imagesjsonControllerService');

module.exports.ImageList = function ImageList(req, res, next) {
  varimagesjsonController.ImageList(req.swagger.params, res, next);
};