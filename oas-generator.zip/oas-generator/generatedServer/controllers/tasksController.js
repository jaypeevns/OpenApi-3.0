'use strict'

var vartasksController = require('./tasksControllerService');

module.exports.TaskList = function TaskList(req, res, next) {
  vartasksController.TaskList(req.swagger.params, res, next);
};