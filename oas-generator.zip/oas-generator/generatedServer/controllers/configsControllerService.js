'use strict'

module.exports.ConfigList = function ConfigList(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ConfigList'
  });
};