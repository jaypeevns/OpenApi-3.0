'use strict'

var varservicescreateController = require('./servicescreateControllerService');

module.exports.ServiceCreate = function ServiceCreate(req, res, next) {
  varservicescreateController.ServiceCreate(req.swagger.params, res, next);
};