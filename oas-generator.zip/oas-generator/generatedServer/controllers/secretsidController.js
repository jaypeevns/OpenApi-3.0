'use strict'

var varsecretsidController = require('./secretsidControllerService');

module.exports.SecretDelete = function SecretDelete(req, res, next) {
  varsecretsidController.SecretDelete(req.swagger.params, res, next);
};

module.exports.SecretInspect = function SecretInspect(req, res, next) {
  varsecretsidController.SecretInspect(req.swagger.params, res, next);
};