'use strict'

var varcontainersidrestartController = require('./containersidrestartControllerService');

module.exports.ContainerRestart = function ContainerRestart(req, res, next) {
  varcontainersidrestartController.ContainerRestart(req.swagger.params, res, next);
};