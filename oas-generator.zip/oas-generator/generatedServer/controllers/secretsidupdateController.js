'use strict'

var varsecretsidupdateController = require('./secretsidupdateControllerService');

module.exports.SecretUpdate = function SecretUpdate(req, res, next) {
  varsecretsidupdateController.SecretUpdate(req.swagger.params, res, next);
};