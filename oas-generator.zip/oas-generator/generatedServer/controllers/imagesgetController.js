'use strict'

var varimagesgetController = require('./imagesgetControllerService');

module.exports.ImageGetAll = function ImageGetAll(req, res, next) {
  varimagesgetController.ImageGetAll(req.swagger.params, res, next);
};