'use strict'

var varcontainersidresizeController = require('./containersidresizeControllerService');

module.exports.ContainerResize = function ContainerResize(req, res, next) {
  varcontainersidresizeController.ContainerResize(req.swagger.params, res, next);
};