'use strict'

module.exports.ContainerAttachWebsocket = function ContainerAttachWebsocket(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ContainerAttachWebsocket'
  });
};