'use strict'

module.exports.ContainerStats = function ContainerStats(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ContainerStats'
  });
};