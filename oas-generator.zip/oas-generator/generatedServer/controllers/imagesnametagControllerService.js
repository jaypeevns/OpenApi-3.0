'use strict'

module.exports.ImageTag = function ImageTag(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ImageTag'
  });
};