'use strict'

var varsystemdfController = require('./systemdfControllerService');

module.exports.SystemDataUsage = function SystemDataUsage(req, res, next) {
  varsystemdfController.SystemDataUsage(req.swagger.params, res, next);
};