'use strict'

module.exports.ImageHistory = function ImageHistory(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ImageHistory'
  });
};