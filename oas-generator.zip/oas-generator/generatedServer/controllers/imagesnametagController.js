'use strict'

var varimagesnametagController = require('./imagesnametagControllerService');

module.exports.ImageTag = function ImageTag(req, res, next) {
  varimagesnametagController.ImageTag(req.swagger.params, res, next);
};