'use strict'

var varcontainersidwaitController = require('./containersidwaitControllerService');

module.exports.ContainerWait = function ContainerWait(req, res, next) {
  varcontainersidwaitController.ContainerWait(req.swagger.params, res, next);
};