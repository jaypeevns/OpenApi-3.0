'use strict'

var varimagesnamejsonController = require('./imagesnamejsonControllerService');

module.exports.ImageInspect = function ImageInspect(req, res, next) {
  varimagesnamejsonController.ImageInspect(req.swagger.params, res, next);
};