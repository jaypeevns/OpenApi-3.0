'use strict'

var varswarmunlockkeyController = require('./swarmunlockkeyControllerService');

module.exports.SwarmUnlockkey = function SwarmUnlockkey(req, res, next) {
  varswarmunlockkeyController.SwarmUnlockkey(req.swagger.params, res, next);
};