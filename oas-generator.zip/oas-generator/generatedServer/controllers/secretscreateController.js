'use strict'

var varsecretscreateController = require('./secretscreateControllerService');

module.exports.SecretCreate = function SecretCreate(req, res, next) {
  varsecretscreateController.SecretCreate(req.swagger.params, res, next);
};