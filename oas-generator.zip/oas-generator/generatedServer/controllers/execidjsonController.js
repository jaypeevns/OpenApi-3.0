'use strict'

var varexecidjsonController = require('./execidjsonControllerService');

module.exports.ExecInspect = function ExecInspect(req, res, next) {
  varexecidjsonController.ExecInspect(req.swagger.params, res, next);
};