'use strict'

module.exports.ContainerLogs = function ContainerLogs(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ContainerLogs'
  });
};