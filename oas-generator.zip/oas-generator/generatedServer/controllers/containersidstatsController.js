'use strict'

var varcontainersidstatsController = require('./containersidstatsControllerService');

module.exports.ContainerStats = function ContainerStats(req, res, next) {
  varcontainersidstatsController.ContainerStats(req.swagger.params, res, next);
};