'use strict'

var varcontainersidupdateController = require('./containersidupdateControllerService');

module.exports.ContainerUpdate = function ContainerUpdate(req, res, next) {
  varcontainersidupdateController.ContainerUpdate(req.swagger.params, res, next);
};