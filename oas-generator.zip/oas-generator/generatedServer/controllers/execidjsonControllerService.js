'use strict'

module.exports.ExecInspect = function ExecInspect(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ExecInspect'
  });
};