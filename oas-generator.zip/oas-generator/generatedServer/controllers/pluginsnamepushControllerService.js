'use strict'

module.exports.PluginPush = function PluginPush(req, res, next) {
  res.send({
    message: 'This is the mockup controller for PluginPush'
  });
};