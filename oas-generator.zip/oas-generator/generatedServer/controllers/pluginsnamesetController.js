'use strict'

var varpluginsnamesetController = require('./pluginsnamesetControllerService');

module.exports.PluginSet = function PluginSet(req, res, next) {
  varpluginsnamesetController.PluginSet(req.swagger.params, res, next);
};