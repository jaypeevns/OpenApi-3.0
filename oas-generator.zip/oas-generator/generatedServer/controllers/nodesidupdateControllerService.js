'use strict'

module.exports.NodeUpdate = function NodeUpdate(req, res, next) {
  res.send({
    message: 'This is the mockup controller for NodeUpdate'
  });
};