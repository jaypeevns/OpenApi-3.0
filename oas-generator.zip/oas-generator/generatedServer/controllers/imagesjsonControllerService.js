'use strict'

module.exports.ImageList = function ImageList(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ImageList'
  });
};