'use strict'

module.exports.ContainerChanges = function ContainerChanges(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ContainerChanges'
  });
};