'use strict'

var varnodesidupdateController = require('./nodesidupdateControllerService');

module.exports.NodeUpdate = function NodeUpdate(req, res, next) {
  varnodesidupdateController.NodeUpdate(req.swagger.params, res, next);
};