'use strict'

var varcommitController = require('./commitControllerService');

module.exports.ImageCommit = function ImageCommit(req, res, next) {
  varcommitController.ImageCommit(req.swagger.params, res, next);
};