'use strict'

module.exports.ContainerPrune = function ContainerPrune(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ContainerPrune'
  });
};