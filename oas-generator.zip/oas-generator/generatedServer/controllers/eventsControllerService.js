'use strict'

module.exports.SystemEvents = function SystemEvents(req, res, next) {
  res.send({
    message: 'This is the mockup controller for SystemEvents'
  });
};