'use strict'

var varcontainersidjsonController = require('./containersidjsonControllerService');

module.exports.ContainerInspect = function ContainerInspect(req, res, next) {
  varcontainersidjsonController.ContainerInspect(req.swagger.params, res, next);
};