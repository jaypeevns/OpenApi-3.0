'use strict'

var varexecidresizeController = require('./execidresizeControllerService');

module.exports.ExecResize = function ExecResize(req, res, next) {
  varexecidresizeController.ExecResize(req.swagger.params, res, next);
};