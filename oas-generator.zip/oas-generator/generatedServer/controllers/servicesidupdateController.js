'use strict'

var varservicesidupdateController = require('./servicesidupdateControllerService');

module.exports.ServiceUpdate = function ServiceUpdate(req, res, next) {
  varservicesidupdateController.ServiceUpdate(req.swagger.params, res, next);
};