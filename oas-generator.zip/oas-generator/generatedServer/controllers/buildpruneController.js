'use strict'

var varbuildpruneController = require('./buildpruneControllerService');

module.exports.BuildPrune = function BuildPrune(req, res, next) {
  varbuildpruneController.BuildPrune(req.swagger.params, res, next);
};