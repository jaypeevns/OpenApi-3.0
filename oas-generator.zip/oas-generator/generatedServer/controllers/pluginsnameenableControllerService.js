'use strict'

module.exports.PluginEnable = function PluginEnable(req, res, next) {
  res.send({
    message: 'This is the mockup controller for PluginEnable'
  });
};