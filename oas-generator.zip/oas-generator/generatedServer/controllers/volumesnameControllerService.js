'use strict'

module.exports.VolumeDelete = function VolumeDelete(req, res, next) {
  res.send({
    message: 'This is the mockup controller for VolumeDelete'
  });
};

module.exports.VolumeInspect = function VolumeInspect(req, res, next) {
  res.send({
    message: 'This is the mockup controller for VolumeInspect'
  });
};