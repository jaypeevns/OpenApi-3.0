'use strict'

var varservicesController = require('./servicesControllerService');

module.exports.ServiceList = function ServiceList(req, res, next) {
  varservicesController.ServiceList(req.swagger.params, res, next);
};