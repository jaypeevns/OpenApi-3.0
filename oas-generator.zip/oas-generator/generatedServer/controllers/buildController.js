'use strict'

var varbuildController = require('./buildControllerService');

module.exports.ImageBuild = function ImageBuild(req, res, next) {
  varbuildController.ImageBuild(req.swagger.params, res, next);
};