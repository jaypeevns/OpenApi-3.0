'use strict'

module.exports.ServiceDelete = function ServiceDelete(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ServiceDelete'
  });
};

module.exports.ServiceInspect = function ServiceInspect(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ServiceInspect'
  });
};