'use strict'

module.exports.ContainerArchive = function ContainerArchive(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ContainerArchive'
  });
};

module.exports.ContainerArchiveInfo = function ContainerArchiveInfo(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ContainerArchiveInfo'
  });
};

module.exports.PutContainerArchive = function PutContainerArchive(req, res, next) {
  res.send({
    message: 'This is the mockup controller for PutContainerArchive'
  });
};