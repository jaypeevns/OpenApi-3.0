'use strict'

var varconfigsController = require('./configsControllerService');

module.exports.ConfigList = function ConfigList(req, res, next) {
  varconfigsController.ConfigList(req.swagger.params, res, next);
};