'use strict'

var varswarminitController = require('./swarminitControllerService');

module.exports.SwarmInit = function SwarmInit(req, res, next) {
  varswarminitController.SwarmInit(req.swagger.params, res, next);
};