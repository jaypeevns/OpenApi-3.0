'use strict'

module.exports.PluginSet = function PluginSet(req, res, next) {
  res.send({
    message: 'This is the mockup controller for PluginSet'
  });
};