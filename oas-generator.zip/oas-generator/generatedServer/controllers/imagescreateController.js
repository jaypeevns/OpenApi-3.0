'use strict'

var varimagescreateController = require('./imagescreateControllerService');

module.exports.ImageCreate = function ImageCreate(req, res, next) {
  varimagescreateController.ImageCreate(req.swagger.params, res, next);
};