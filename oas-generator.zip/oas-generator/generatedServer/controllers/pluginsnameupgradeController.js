'use strict'

var varpluginsnameupgradeController = require('./pluginsnameupgradeControllerService');

module.exports.PluginUpgrade = function PluginUpgrade(req, res, next) {
  varpluginsnameupgradeController.PluginUpgrade(req.swagger.params, res, next);
};