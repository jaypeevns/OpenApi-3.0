'use strict'

module.exports.ContainerInspect = function ContainerInspect(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ContainerInspect'
  });
};