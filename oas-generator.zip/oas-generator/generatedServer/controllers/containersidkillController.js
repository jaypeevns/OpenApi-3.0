'use strict'

var varcontainersidkillController = require('./containersidkillControllerService');

module.exports.ContainerKill = function ContainerKill(req, res, next) {
  varcontainersidkillController.ContainerKill(req.swagger.params, res, next);
};