'use strict'

module.exports.SwarmInspect = function SwarmInspect(req, res, next) {
  res.send({
    message: 'This is the mockup controller for SwarmInspect'
  });
};