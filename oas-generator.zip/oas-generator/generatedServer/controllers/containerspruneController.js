'use strict'

var varcontainerspruneController = require('./containerspruneControllerService');

module.exports.ContainerPrune = function ContainerPrune(req, res, next) {
  varcontainerspruneController.ContainerPrune(req.swagger.params, res, next);
};