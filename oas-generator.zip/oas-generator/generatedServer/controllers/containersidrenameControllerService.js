'use strict'

module.exports.ContainerRename = function ContainerRename(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ContainerRename'
  });
};