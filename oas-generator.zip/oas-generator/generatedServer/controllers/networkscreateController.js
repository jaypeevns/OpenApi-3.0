'use strict'

var varnetworkscreateController = require('./networkscreateControllerService');

module.exports.NetworkCreate = function NetworkCreate(req, res, next) {
  varnetworkscreateController.NetworkCreate(req.swagger.params, res, next);
};