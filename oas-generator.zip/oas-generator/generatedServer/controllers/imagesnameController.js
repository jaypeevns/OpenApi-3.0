'use strict'

var varimagesnameController = require('./imagesnameControllerService');

module.exports.ImageDelete = function ImageDelete(req, res, next) {
  varimagesnameController.ImageDelete(req.swagger.params, res, next);
};