'use strict'

module.exports.NetworkPrune = function NetworkPrune(req, res, next) {
  res.send({
    message: 'This is the mockup controller for NetworkPrune'
  });
};