'use strict'

var varpluginsprivilegesController = require('./pluginsprivilegesControllerService');

module.exports.GetPluginPrivileges = function GetPluginPrivileges(req, res, next) {
  varpluginsprivilegesController.GetPluginPrivileges(req.swagger.params, res, next);
};