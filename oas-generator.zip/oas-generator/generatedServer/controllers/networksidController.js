'use strict'

var varnetworksidController = require('./networksidControllerService');

module.exports.NetworkDelete = function NetworkDelete(req, res, next) {
  varnetworksidController.NetworkDelete(req.swagger.params, res, next);
};

module.exports.NetworkInspect = function NetworkInspect(req, res, next) {
  varnetworksidController.NetworkInspect(req.swagger.params, res, next);
};