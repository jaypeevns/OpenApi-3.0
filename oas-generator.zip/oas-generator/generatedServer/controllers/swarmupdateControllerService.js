'use strict'

module.exports.SwarmUpdate = function SwarmUpdate(req, res, next) {
  res.send({
    message: 'This is the mockup controller for SwarmUpdate'
  });
};