'use strict'

var varvolumesnameController = require('./volumesnameControllerService');

module.exports.VolumeDelete = function VolumeDelete(req, res, next) {
  varvolumesnameController.VolumeDelete(req.swagger.params, res, next);
};

module.exports.VolumeInspect = function VolumeInspect(req, res, next) {
  varvolumesnameController.VolumeInspect(req.swagger.params, res, next);
};