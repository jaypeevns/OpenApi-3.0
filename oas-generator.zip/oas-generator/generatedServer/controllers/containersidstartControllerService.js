'use strict'

module.exports.ContainerStart = function ContainerStart(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ContainerStart'
  });
};