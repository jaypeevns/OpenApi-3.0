'use strict'

module.exports.SystemAuth = function SystemAuth(req, res, next) {
  res.send({
    message: 'This is the mockup controller for SystemAuth'
  });
};