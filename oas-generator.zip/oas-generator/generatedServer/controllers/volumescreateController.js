'use strict'

var varvolumescreateController = require('./volumescreateControllerService');

module.exports.VolumeCreate = function VolumeCreate(req, res, next) {
  varvolumescreateController.VolumeCreate(req.swagger.params, res, next);
};