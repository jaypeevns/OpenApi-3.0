'use strict'

var varvolumesController = require('./volumesControllerService');

module.exports.VolumeList = function VolumeList(req, res, next) {
  varvolumesController.VolumeList(req.swagger.params, res, next);
};