'use strict'

var varpluginsnamedisableController = require('./pluginsnamedisableControllerService');

module.exports.PluginDisable = function PluginDisable(req, res, next) {
  varpluginsnamedisableController.PluginDisable(req.swagger.params, res, next);
};