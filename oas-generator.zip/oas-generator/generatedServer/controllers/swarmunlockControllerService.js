'use strict'

module.exports.SwarmUnlock = function SwarmUnlock(req, res, next) {
  res.send({
    message: 'This is the mockup controller for SwarmUnlock'
  });
};