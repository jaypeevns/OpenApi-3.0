'use strict'

var varcontainersidstopController = require('./containersidstopControllerService');

module.exports.ContainerStop = function ContainerStop(req, res, next) {
  varcontainersidstopController.ContainerStop(req.swagger.params, res, next);
};