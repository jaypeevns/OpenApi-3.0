'use strict'

var varnetworksidconnectController = require('./networksidconnectControllerService');

module.exports.NetworkConnect = function NetworkConnect(req, res, next) {
  varnetworksidconnectController.NetworkConnect(req.swagger.params, res, next);
};