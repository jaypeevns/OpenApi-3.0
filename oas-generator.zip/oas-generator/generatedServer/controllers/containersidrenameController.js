'use strict'

var varcontainersidrenameController = require('./containersidrenameControllerService');

module.exports.ContainerRename = function ContainerRename(req, res, next) {
  varcontainersidrenameController.ContainerRename(req.swagger.params, res, next);
};