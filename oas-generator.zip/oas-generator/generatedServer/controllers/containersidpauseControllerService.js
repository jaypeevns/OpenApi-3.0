'use strict'

module.exports.ContainerPause = function ContainerPause(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ContainerPause'
  });
};