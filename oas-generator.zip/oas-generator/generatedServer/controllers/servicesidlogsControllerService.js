'use strict'

module.exports.ServiceLogs = function ServiceLogs(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ServiceLogs'
  });
};