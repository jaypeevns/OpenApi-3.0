'use strict'

module.exports.ImageBuild = function ImageBuild(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ImageBuild'
  });
};