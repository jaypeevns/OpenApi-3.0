'use strict'

module.exports.PluginPull = function PluginPull(req, res, next) {
  res.send({
    message: 'This is the mockup controller for PluginPull'
  });
};