'use strict'

var varpluginsnameenableController = require('./pluginsnameenableControllerService');

module.exports.PluginEnable = function PluginEnable(req, res, next) {
  varpluginsnameenableController.PluginEnable(req.swagger.params, res, next);
};