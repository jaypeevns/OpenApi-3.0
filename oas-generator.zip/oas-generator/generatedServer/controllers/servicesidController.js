'use strict'

var varservicesidController = require('./servicesidControllerService');

module.exports.ServiceDelete = function ServiceDelete(req, res, next) {
  varservicesidController.ServiceDelete(req.swagger.params, res, next);
};

module.exports.ServiceInspect = function ServiceInspect(req, res, next) {
  varservicesidController.ServiceInspect(req.swagger.params, res, next);
};