'use strict'

var varpluginspullController = require('./pluginspullControllerService');

module.exports.PluginPull = function PluginPull(req, res, next) {
  varpluginspullController.PluginPull(req.swagger.params, res, next);
};