'use strict'

module.exports.PluginCreate = function PluginCreate(req, res, next) {
  res.send({
    message: 'This is the mockup controller for PluginCreate'
  });
};