'use strict'

module.exports.SwarmLeave = function SwarmLeave(req, res, next) {
  res.send({
    message: 'This is the mockup controller for SwarmLeave'
  });
};