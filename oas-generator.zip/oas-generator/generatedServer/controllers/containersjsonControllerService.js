'use strict'

module.exports.ContainerList = function ContainerList(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ContainerList'
  });
};