'use strict'

var varimagesloadController = require('./imagesloadControllerService');

module.exports.ImageLoad = function ImageLoad(req, res, next) {
  varimagesloadController.ImageLoad(req.swagger.params, res, next);
};