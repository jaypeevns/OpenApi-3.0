'use strict'

module.exports.VolumeList = function VolumeList(req, res, next) {
  res.send({
    message: 'This is the mockup controller for VolumeList'
  });
};