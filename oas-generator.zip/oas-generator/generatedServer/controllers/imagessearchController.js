'use strict'

var varimagessearchController = require('./imagessearchControllerService');

module.exports.ImageSearch = function ImageSearch(req, res, next) {
  varimagessearchController.ImageSearch(req.swagger.params, res, next);
};