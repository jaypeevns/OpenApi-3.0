'use strict'

module.exports.NetworkList = function NetworkList(req, res, next) {
  res.send({
    message: 'This is the mockup controller for NetworkList'
  });
};