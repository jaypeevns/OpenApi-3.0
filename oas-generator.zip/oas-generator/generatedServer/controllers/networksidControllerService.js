'use strict'

module.exports.NetworkDelete = function NetworkDelete(req, res, next) {
  res.send({
    message: 'This is the mockup controller for NetworkDelete'
  });
};

module.exports.NetworkInspect = function NetworkInspect(req, res, next) {
  res.send({
    message: 'This is the mockup controller for NetworkInspect'
  });
};