'use strict'

module.exports.ImageCreate = function ImageCreate(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ImageCreate'
  });
};