'use strict'

module.exports.ContainerRestart = function ContainerRestart(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ContainerRestart'
  });
};