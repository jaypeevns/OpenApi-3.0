'use strict'

var varswarmController = require('./swarmControllerService');

module.exports.SwarmInspect = function SwarmInspect(req, res, next) {
  varswarmController.SwarmInspect(req.swagger.params, res, next);
};