'use strict'

var varvolumespruneController = require('./volumespruneControllerService');

module.exports.VolumePrune = function VolumePrune(req, res, next) {
  varvolumespruneController.VolumePrune(req.swagger.params, res, next);
};