'use strict'

module.exports.ConfigDelete = function ConfigDelete(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ConfigDelete'
  });
};

module.exports.ConfigInspect = function ConfigInspect(req, res, next) {
  res.send({
    message: 'This is the mockup controller for ConfigInspect'
  });
};