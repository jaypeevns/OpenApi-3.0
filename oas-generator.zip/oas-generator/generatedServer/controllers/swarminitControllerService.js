'use strict'

module.exports.SwarmInit = function SwarmInit(req, res, next) {
  res.send({
    message: 'This is the mockup controller for SwarmInit'
  });
};