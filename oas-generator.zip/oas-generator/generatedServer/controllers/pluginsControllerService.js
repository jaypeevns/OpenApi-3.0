'use strict'

module.exports.PluginList = function PluginList(req, res, next) {
  res.send({
    message: 'This is the mockup controller for PluginList'
  });
};