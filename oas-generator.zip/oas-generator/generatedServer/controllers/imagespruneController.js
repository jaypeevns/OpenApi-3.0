'use strict'

var varimagespruneController = require('./imagespruneControllerService');

module.exports.ImagePrune = function ImagePrune(req, res, next) {
  varimagespruneController.ImagePrune(req.swagger.params, res, next);
};