'use strict'

var varconfigsidupdateController = require('./configsidupdateControllerService');

module.exports.ConfigUpdate = function ConfigUpdate(req, res, next) {
  varconfigsidupdateController.ConfigUpdate(req.swagger.params, res, next);
};