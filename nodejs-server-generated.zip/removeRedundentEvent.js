var soap = require("soap");
var etag = require("etag");
var cron = require('node-cron');
var _ = require('underscore');
var queryString = require('querystring');
var request = require('request');
var async = require('async');
const utf8 = require('utf8');
const crypto = require('crypto');
var linkedMap = require('linked-map');
var logger = require('./logger');
var USER_NAME = 'PUBSUB_INTEG_USER';
exports.USER_NAME = USER_NAME;
var PASSWORD = "88XdMta#4KHPu2";
exports.PASSWORD = PASSWORD;
exports.SVC_WSDL_PATH = 'https://ngpsservice.custhelp.com/services/soap/connect/soap?wsdl ';
var BASE_URL = 'https://ngpsservice.custhelp.com/services/rest/connect/v1.3/';
exports.BASE_URL = BASE_URL;
var AUTH_TYPE = "Basic ";
exports.AUTH_TYPE = AUTH_TYPE;
var ENCODE_TYPE = "base64";
exports.ENCODE_TYPE = ENCODE_TYPE;
var SINGLE_RECORD = 0;
exports.SINGLE_RECORD = SINGLE_RECORD;
exports.ResourceUri = "https://dnvgl-esb.servicebus.windows.net/osvc_osvcintegration";
exports.KeyName = "osvc_send";
exports.Key = "UhEu/FPlHq2g42Z1IRqUQlv+BFVXpGUiWW8MvCoTrbk=";
exports.serviceBusAddress = "https://dnvgl-esb.servicebus.windows.net/osvc_osvcintegration/messages";  
exports.limit = process.env.BatchSize || 1000;

cron.schedule('1 */3 * * * *', function () {
    var date = new Date();
    logger.info('Event loop starts @@  ' + date.toISOString());
    var container = {};
    var finalMap = new linkedMap();
    var dulicateGroupMap = new linkedMap();
    var failedRecords = [];
    var token = createToken(public_constants.ResourceUri, public_constants.KeyName, public_constants.Key);

    async.series([
        function (callback1) {
            getEvents(container, date, callback1);
        }, function (callback3) {
            pushEvents(container, finalMap, dulicateGroupMap, callback3);
        }, function (callback2) {
            sendMessage(finalMap, token, public_constants.serviceBusAddress, dulicateGroupMap, failedRecords, callback2);
        }, function (callback4) {
            var finalXMlContainer = {};
            finalXMlContainer.finalXMl = "";            
            async.forEach(dulicateGroupMap.values(), function (item, callback_async) {
                var extractedData = public_constants.updatePubSubPayLoad;
                extractedData = extractedData.replace("[PubSubID]", item);
                var status = 'completed';
                if(_.contains(failedRecords,item)){
                    status = 'new';
                }                
                extractedData = public_constants.addStringAttribute("Status", status, extractedData);
                finalXMlContainer.finalXMl = finalXMlContainer.finalXMl + extractedData;
                callback_async();
            }, function (err) {
                if (err) {
                    callback4();
                } else {                    
                    if (finalXMlContainer.finalXMl) {
                        var commonXmlTemplate = public_constants.updatePubSubCommonTemplate.replace("[CustomTemplateString]", finalXMlContainer.finalXMl);
                        public_constants.queryUsingSoapBatch(commonXmlTemplate, function (result) {
                            errObj = _.find(result.BatchResponseItem, function (obj) {
                                return _.keys(obj).includes('exceptionCode')
                            });
                            if (errObj) {
                                callback4(new Error(errObj.exceptionMessage));
                            } else {
                                callback4();
                            }
                        });

                    } else {
                        callback4();
                    }                    
                }
            });
        }], function (err) {
            if (err) {
                logger.error(err);
                logger.error('Event loop ends @@  ' + new Date().toISOString());                
                return (err);
            } else {
                logger.info('Event loop ends @@  ' + new Date().toISOString());
                logger.info('success');                
                return ("Success");
            }
        });
});

var public_constants = require('./removeRedundentEvent.js');
exports.getAuthToken = function () {
    var username = public_constants.USER_NAME;
    var password = public_constants.PASSWORD;
    var authType = public_constants.AUTH_TYPE;
    var encodeType = public_constants.ENCODE_TYPE;
    var token = authType + new Buffer(username + ":" + password).toString(encodeType);
    return token;
}

exports.getOptions = function (uri) {
    return options = {
        url: public_constants.BASE_URL + uri,
        headers: {
            'Authorization': public_constants.getAuthToken()
        }
    };
}

exports.objectifyQueryResult = function (items) {
    var dataItems = [];
    for (var index = 0; index < items.length; index++) {
        var item = items[index];
        var columnNames = item.columnNames;
        var rowCount = item.rows.length;
        var columnCount = columnNames.length;

        var rows = [];

        for (var i = 0; i < rowCount; i++) {
            var row = {};
            for (var j = 0; j < columnCount; j++) {
                row[columnNames[j]] = items[index].rows[i][j];
            }
            rows.push(row);
        }
        //array of objects
        dataItems.push(rows);
    }
    if (dataItems.length == 1) {
        return dataItems[0];
    } else {
        return dataItems;
    }
}

function getEvents(container, date, callback) {

    var roql = 'select ' +
        'id,' +
        'ObjectId, ' +
        'ObjectName,' +
        'ParentKey, ' +
        'ParentObjectName,' +
        'RelationShipId1, ' +
        'RelationShipObjectName1,' +
        'RelationShipId2, ' +
        'RelationShipObjectName2,' +
        'RelationShipId3, ' +
        'RelationShipObjectName3,' +
        'ActionEvent, ' +
        'GrandParentKey, ' +
        'GrandParentName, ' +
        'Status ' +
        'from CO1.PubSub where status  in (\'new\') Order By updatedTime ASC LIMIT ' + public_constants.limit;       

    roql = queryString.escape(roql);
    var uri = 'queryResults/?query=' + roql;
    var options = public_constants.getOptions(uri);
    request(options, getResult);

    function getResult(error, response) {
        if (!error && response.statusCode == 200) {
            container.result = public_constants.objectifyQueryResult(JSON.parse(response.body).items);
            var finalXMlContainer = {};
            finalXMlContainer.finalXMl = "";
            async.forEach(container.result, function (item, callback_async) {
                var extractedData = public_constants.updatePubSubPayLoad;
                extractedData = extractedData.replace("[PubSubID]", item.id);
                extractedData = public_constants.addStringAttribute("Status", "duplicate", extractedData);
                finalXMlContainer.finalXMl = finalXMlContainer.finalXMl + extractedData;
                callback_async();
            }, function (err) {
                if (err) {
                    callback();
                } else {
                    if (finalXMlContainer.finalXMl) {
                        var commonXmlTemplate = public_constants.updatePubSubCommonTemplate.replace("[CustomTemplateString]", finalXMlContainer.finalXMl);
                        public_constants.queryUsingSoapBatch(commonXmlTemplate, function (result) {
                            errObj = _.find(result.BatchResponseItem, function (obj) {
                                return _.keys(obj).includes('exceptionCode')
                            });
                            if (errObj) {
                                logger.error(errObj.exceptionMessage);
                                callback(new Error(errObj.exceptionMessage));
                            } else {
                                callback();
                            }
                        });

                    } else {
                        callback();
                    }
                }
            });
        } else {
            callback(error);
        }
    }

}
exports.addStringAttribute = function (template, replaceValue, extractedData) {
    var strIndex = '</q1:ObjectType>';
    var indexOfReplace = extractedData.indexOf(strIndex);
    var len = strIndex.length;
    var str;
    if (replaceValue) {
        str = "<q1:GenericFields dataType=\"STRING\" name=\"" + template + "\"><q1:DataValue> <q1:StringValue><![CDATA[[" + template + "]]]></q1:StringValue></q1:DataValue> </q1:GenericFields>";
        str = str.replace("[" + template + "]", replaceValue);
    } else {
        str = "<q1:GenericFields dataType=\"STRING\" name=\"" + template + "\"><q1:DataValue xsi:nil=\"true\"> <q1:StringValue><![CDATA[[" + template + "]]]></q1:StringValue></q1:DataValue> </q1:GenericFields>";
        str = str.replace('<![CDATA[[' + template + ']]]>', null);
    }

    return [extractedData.slice(0, indexOfReplace + len), str, extractedData.slice(indexOfReplace + len)].join('');
}
function cretaeEventMap(container, finalMap, callback) {
    async.forEach(container.result, function (item, callback_async) {
        var map = {
            TableName: item.ObjectName,
            RowId: item.ObjectId,
            ActionEvent: item.ActionEvent
        }
        finalMap.push(Object.values(map), item);        
        callback_async();
    }, function (err) {
        if (err) {
            callback();
        } else {
            callback();
        }
    });

}

function pushEvents(container, finalMap, dulicateGroupMap, callback) {    
    async.forEach(container.result, function (value, callback_async) {
        var objServiceCloud = value;
        var rowID = objServiceCloud.id;
        var caseSwitch = value.ObjectName;
        var childETag='';
        var parentETag = '';

        switch (caseSwitch) {
            case "RO.CertServiceSite2Std":
            case "RO.CertServiceStd2Acr":
                objServiceCloudChildData = assignFieldsChildObject(objServiceCloud);
                childETag = getETagValue(objServiceCloudChildData);
                finalMap.push(childETag, objServiceCloudChildData);
                dulicateGroupMap.push(childETag, rowID);
                objServiceCloud = assignFieldsParentObject(objServiceCloud);
                parentETag = getETagValue(objServiceCloud);
                finalMap.push(parentETag, objServiceCloud);
                dulicateGroupMap.push(parentETag, rowID);
                callback_async();
                break;
            case "RO.Certificate2Site":
            case "RO.CertificateStdAcr":
                objServiceCloudChildData = assignFieldsChildObject(objServiceCloud);
                childETag = getETagValue(objServiceCloudChildData);
                finalMap.push(childETag, objServiceCloudChildData);
                dulicateGroupMap.push(childETag, rowID);
                callback_async();
                break;
            case "RO.Findings2StdClause":
                objServiceCloudChildData = assignFieldsChildObject(objServiceCloud);
                childETag = getETagValue(objServiceCloudChildData);
                finalMap.push(childETag, objServiceCloudChildData);
                dulicateGroupMap.push(childETag, rowID);
                callback_async();
                break;
            case "RO.Findings2FocusArea":
            case "RO.Findings2Site":
                objServiceCloudChildData = assignFieldsChildObject(objServiceCloud);
                childETag = getETagValue(objServiceCloudChildData);
                finalMap.push(etag(childETag, objServiceCloudChildData));
                dulicateGroupMap.push(childETag, rowID);
                callback_async();
                break;
            case  "CO.RequestTeam":
                objServiceCloudChildKey  =  assignFieldsToRequestTeamt(objServiceCloud);
                objServiceCloudChildValue  =  assignFieldsParentObject(objServiceCloud);
                var childETag = getETagValue(objServiceCloudChildKey);
                finalMap.push(childETag, objServiceCloudChildValue);
                dulicateGroupMap.push(childETag, rowID);
                callback_async();
                break;
            default:
                objServiceCloud = assignFieldsParentObject(objServiceCloud);
                parentETag = getETagValue(objServiceCloud);
                finalMap.push(parentETag, objServiceCloud);
                dulicateGroupMap.push(parentETag, rowID);
                callback_async();
        }
    }, function (err) {
        if (err) {
            callback(err);
        } else {
            callback();
        }
    });
}

function  assignFieldsToRequestTeamt(objServiceCloudChildObject) {
    var  obj  =  {};

    obj.ObjectId  =  objServiceCloudChildObject.ParentKey;
    obj.ObjectName  =  objServiceCloudChildObject.ParentObjectName;
    obj.ParentKey  =  null;
    obj.ParentObjectName  =  null;
    //obj.ChildKey = objServiceCloudChildObject.ObjectId;
    ///obj.ChildObjectName = objServiceCloudChildObject.ObjectName;
    obj.GrandParentKey  =  objServiceCloudChildObject.GrandParentKey;
    obj.GrandParentName  =  objServiceCloudChildObject.GrandParentName;
    obj.RelationShipId1  =  objServiceCloudChildObject.RelationShipId1;
    obj.RelationShipObjectName1  =  objServiceCloudChildObject.RelationShipObjectName1;
    obj.RelationShipId2  =  objServiceCloudChildObject.RelationShipId2;
    obj.RelationShipObjectName2  =  objServiceCloudChildObject.RelationShipObjectName2;
    obj.RelationShipId3  =  objServiceCloudChildObject.RelationShipId3;
    obj.RelationShipObjectName3  =  objServiceCloudChildObject.RelationShipObjectName3;
    obj.ActionEvent  =  objServiceCloudChildObject.ActionEvent;

    return  obj;
} 

function assignFieldsParentObject(objServiceCloudParentObject) {
    var obj = {};

    obj.ObjectId = objServiceCloudParentObject.ObjectId;
    obj.ObjectName = objServiceCloudParentObject.ObjectName;
    obj.ParentKey = objServiceCloudParentObject.ParentKey;
    obj.ParentObjectName = objServiceCloudParentObject.ParentObjectName;
    obj.ChildKey = null;
    obj.ChildObjectName = null;
    obj.GrandParentKey = objServiceCloudParentObject.GrandParentKey;
    obj.GrandParentName = objServiceCloudParentObject.GrandParentName;
    obj.RelationShipId1 = objServiceCloudParentObject.RelationShipId1;
    obj.RelationShipObjectName1 = objServiceCloudParentObject.RelationShipObjectName1;
    obj.RelationShipId2 = objServiceCloudParentObject.RelationShipId2;
    obj.RelationShipObjectName2 = objServiceCloudParentObject.RelationShipObjectName2;
    obj.RelationShipId3 = objServiceCloudParentObject.RelationShipId3;
    obj.RelationShipObjectName3 = objServiceCloudParentObject.RelationShipObjectName3;
    obj.ActionEvent = objServiceCloudParentObject.ActionEvent;

    return obj;
}

function assignFieldsChildObject(objServiceCloudChildObject) {
    var obj = {};

    obj.ObjectId = objServiceCloudChildObject.ParentKey;
    obj.ObjectName = objServiceCloudChildObject.ParentObjectName;
    obj.ParentKey = null;
    obj.ParentObjectName = null;
    obj.ChildKey = objServiceCloudChildObject.ObjectId;
    obj.ChildObjectName = objServiceCloudChildObject.ObjectName;
    obj.GrandParentKey = objServiceCloudChildObject.GrandParentKey;
    obj.GrandParentName = objServiceCloudChildObject.GrandParentName;
    obj.RelationShipId1 = objServiceCloudChildObject.RelationShipId1;
    obj.RelationShipObjectName1 = objServiceCloudChildObject.RelationShipObjectName1;
    obj.RelationShipId2 = objServiceCloudChildObject.RelationShipId2;
    obj.RelationShipObjectName2 = objServiceCloudChildObject.RelationShipObjectName2;
    obj.RelationShipId3 = objServiceCloudChildObject.RelationShipId3;
    obj.RelationShipObjectName3 = objServiceCloudChildObject.RelationShipObjectName3;
    obj.ActionEvent = objServiceCloudChildObject.ActionEvent;

    return obj;
}

function sendMessage(finalMap, token, serviceBusAddress, dulicateGroupMap, failedRecords, callback) { 
    logger.info('Total records for processing:'+finalMap.size()); 
    var successCount = 0;     
    var notFoundCount = 0;
    async.forEach(finalMap.keys(), function (key, callback_async) {
        var objServiceCloudSendMessage = finalMap.get(key);
        if(objServiceCloudSendMessage){
        var request_payload = {
            "id": objServiceCloudSendMessage.ObjectId,
            "ObjectName": objServiceCloudSendMessage.ObjectName,
            "ParentKey": objServiceCloudSendMessage.ParentKey,
            "ParentObjectName": objServiceCloudSendMessage.ParentObjectName,
            "ChildKey": objServiceCloudSendMessage.ChildKey,
            "ChildObjectName": objServiceCloudSendMessage.ChildObjectName,
            "GrandParentKey": objServiceCloudSendMessage.GrandParentKey,
            "GrandParentName": objServiceCloudSendMessage.GrandParentName,
            "RelationShipId1": objServiceCloudSendMessage.RelationShipId1,
            "RelationShipObjectName1": objServiceCloudSendMessage.RelationShipObjectName1,
            "RelationShipId2": objServiceCloudSendMessage.RelationShipId2,
            "RelationShipObjectName2": objServiceCloudSendMessage.RelationShipObjectName2,
            "RelationShipId3": objServiceCloudSendMessage.RelationShipId3,
            "RelationShipObjectName3": objServiceCloudSendMessage.RelationShipObjectName3,
            "ActionEvent": objServiceCloudSendMessage.ActionEvent
        };
        var options = getPostOptions(request_payload, token, serviceBusAddress);
        request(options, function (error, response, body) {
            if (!error && response.statusCode == 201) { 
                successCount = successCount + 1;
                callback_async();
            } else {
                logger.error('Failure for Record:'+JSON.stringify(request_payload));
                failedRecords.push(dulicateGroupMap.get(key));
                callback_async();
            }
        });        
    }
    else{
        notFoundCount = notFoundCount + 1;
        logger.warn('No value found in final Map for key:'+key);        
        var rowId = dulicateGroupMap.get(key);
        if(rowId){
            logger.warn(rowId+' value found in duplicate Map for key:'+key);
            failedRecords.push(rowId);
        }
        else{
            logger.warn('No value found in duplicate Map for key:'+key);  
        } 
        callback_async()       
    }
    }, function (err) {
        logger.info('Records processed successfully:'+successCount);
        logger.info('Records fail:'+failedRecords.length);
        logger.info('Records not found:'+notFoundCount);
        if (err) {
            callback();
        } else {
            callback();
        }
    });
}

function getPostOptions(request_payload, token, serviceBusAddress) {
    return options = {
        url: serviceBusAddress,
        json: request_payload,
        method: 'POST',
        headers: {
            'Authorization': token,
            'Content-Type': 'application/json',
            'ObjectName': request_payload.ObjectName
        }
    };
};


function createToken(uri, saName, saKey) {
    if (!uri || !saName || !saKey) {
        throw "Missing required parameter";
    }
    var encoded = encodeURIComponent(uri);
    var now = new Date();
    var week = 60 * 60 * 24 * 7;
    var ttl = Math.round(now.getTime() / 1000) + week;
    var signature = encoded + '\n' + ttl;
    var signatureUTF8 = utf8.encode(signature);
    var hash = crypto.createHmac('sha256', saKey).update(signatureUTF8).digest('base64');
    return 'SharedAccessSignature sr=' + encoded + '&sig=' +
        encodeURIComponent(hash) + '&se=' + ttl + '&skn=' + saName;
}

function getETagValue(inputObj){
    var cloneObj = _.clone(inputObj);
    if(cloneObj.ActionEvent != 'DeleteEvent'){
        delete cloneObj.ActionEvent;
    }
    return etag(JSON.stringify(cloneObj));
}



exports.updatePubSubPayLoad = (function () {/* <RNObjects xsi:type="q1:GenericObject" xmlns:q1="urn:generic.ws.rightnow.com/v1_4"> 
            <ID id="[PubSubID]" xmlns="urn:base.ws.rightnow.com/v1_4"/>     
            <q1:ObjectType>
            <q1:Namespace>CO1</q1:Namespace>
            <q1:TypeName>PubSub</q1:TypeName>
            </q1:ObjectType>      
            </RNObjects> */}).toString().match(/[^]*\/\*([^]*)\*\/\}$/)[1];


exports.updatePubSubCommonTemplate = (function () {/*
                  <Batch xmlns="urn:messages.ws.rightnow.com/v1_4">
                  <BatchRequestItem>
                  <UpdateMsg>
                       [CustomTemplateString]
                        <ProcessingOptions>
                        <SuppressExternalEvents>false</SuppressExternalEvents>
                        <SuppressRules>false</SuppressRules>
                        </ProcessingOptions>
                  </UpdateMsg>
                  <CommitAfter>true</CommitAfter>
                  <PreserveChainID>true</PreserveChainID>
                  </BatchRequestItem>
                  </Batch>*/}).toString().match(/[^]*\/\*([^]*)\*\/\}$/)[1];


exports.queryUsingSoapBatch = function (finalXmlTemplate, callback) {
    soap.createClientAsync(public_constants.SVC_WSDL_PATH)
        .then(client => {
            client.setSecurity(new soap.WSSecurity(public_constants.USER_NAME, public_constants.PASSWORD, { hasTimeStamp: false }));

            client.addSoapHeader(
                ' <h:ClientInfoHeader xmlns="urn:messages.ws.rightnow.com/v1_4" xmlns:h="urn:messages.ws.rightnow.com/v1_4" xmlns:xsd="http://www.w3.org/2001/XMLSchema"' +
                ' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">' +
                '<AppID> Custom Objects Samples</AppID></h:ClientInfoHeader>'
            );

            var args = {
                _xml: finalXmlTemplate
            };

            client.BatchAsync(args)
                .then(result => {                    
                    callback(result[0]);
                })
                .catch(err => {
                    logger.error(err.stack);                    
                    callback(err);
                });
        })
        .catch(err => {
            logger.error(err.stack);
            callback(err);
        });
};
