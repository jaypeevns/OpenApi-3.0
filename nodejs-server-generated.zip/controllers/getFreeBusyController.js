'use strict'

var vargetFreeBusyController = require('./getFreeBusyControllerService');

module.exports.getfreebusy = function getfreebusy(req, res, next) {
  vargetFreeBusyController.getfreebusy(req.swagger.params, res, next);
};